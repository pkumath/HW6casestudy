# Re-importing the pandas package as the code execution state was reset
import pandas as pd

# Reading the uploaded athlete_data.csv file again
file_path = 'athlete_data.csv'
data = pd.read_csv(file_path)

# Formatting the Date/Session column
data['Date/Session'] = pd.to_datetime(data['Date/Session'], format='%m/%d/%Y').dt.strftime('%Y-%m-%d')

# Writing the formatted data to a new file
formatted_file_path = 'athlete_data_formatted.csv'
data.to_csv(formatted_file_path, index=False)

formatted_file_path
