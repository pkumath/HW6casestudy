library(dplyr)
library(lubridate)
library(tidyverse)
library(tools)
library(stringr)
library(readxl)


setwd("~/Documents/GitHub/425-625-Fall-2023_2/yale-athletic-dept-data")

## COLS REMOVED FROM FORCE: TestId, Time
## COLS REMOVED FROM GPS: Split Start Time, Split End Time, Split-Name (redundant when we have Session Title)
# gps session = Session Title, force session = Type
# gps Tags = force Tags


## START OF NAMES
## NOTE: ANDERSON JR = DAMIAN ANDERSON JR and ANDERSON JR. = BENNIE ANDERSON JR.

force <- read_csv("rawdata/Football_-01_20_23-11_05_23-_Countermovement_Jump.csv")
gps <- read_excel("rawdata/Yale Football Catapult Raw Data 2023.xlsx")

# removing players with unknown names
gps <- gps[!is.na(gps$`Player Name`), ]

# changing unknown positions to say unknown instead of NA in force
for (i in 1:nrow(force)){
  if(is.na(force$Position[i])){
    force$Position[i] <- "unknown"
  }
}

# Changing all instance of N/A to NA in force
force <- as.data.frame(lapply(force, function(x) {gsub("N/A", NA, x)
             }))





# making all names be uppercase
force <- force %>% 
  mutate(Name = toupper(Name))
gps <- gps %>% mutate(`Player Name` = toupper(`Player Name`))

## fixing names listed far below
force$Name <- str_replace(force$Name, "FADEYIBII", "FADEYIBI")
gps$`Player Name` <- str_replace(gps$`Player Name`, "SCHUTZMANN", "SCHUTZMAN")
force$Name <- (str_replace(force$Name, "DIIENNO", "DIIENO"))
gps$`Player Name` <- str_replace(gps$`Player Name`, "ANDERSON JR", "ANDERSON JR D")
gps$`Player Name` <- str_replace(gps$`Player Name`, "ANDERSON B", "ANDERSON JR. B")




# getting unique names from force and gps, omitting NAs, and changing col name to Name
lookup_force <- na.omit(as.data.frame(unique(force$Name)))
lookup_gps <- na.omit(as.data.frame(unique(gps$`Player Name`)))
colnames(lookup_force) <- ("Name")
colnames(lookup_gps) <- ("Name")




# adding last name col to lookup tables
lookup_force <- lookup_force %>% 
  mutate(last = case_when(word(lookup_force$Name, -1) == "JR" ~ paste(word(lookup_force$Name, -2), word(lookup_force$Name, -1)), 
                          word(lookup_force$Name, -1) == "JR." ~ paste(word(lookup_force$Name, -2), word(lookup_force$Name, -1)),
                          word(lookup_force$Name, -1) == "AUBYN" ~ paste(word(lookup_force$Name, -2), word(lookup_force$Name, -1)),
                          TRUE ~ word(lookup_force$Name, -1)))



lookup_gps <- lookup_gps %>% 
  mutate(last =  case_when(word(lookup_gps$Name, 1) == "ST." ~ paste(word(lookup_gps$Name, 1), word(lookup_gps$Name, 2)),
                           word(lookup_gps$Name, 2) == "JR" ~ paste(word(lookup_gps$Name, 1), word(lookup_gps$Name, 2)),
                           word(lookup_gps$Name, 2) == "JR." ~ paste(word(lookup_gps$Name, 1), word(lookup_gps$Name, 2)),
                           TRUE ~ word(lookup_gps$Name, 1)))



# Check what names need to be changed
for (i in 1:nrow(lookup_force)) {
  if(!(lookup_force$last[i] %in% lookup_gps$last)){
    cat(lookup_force$last[i], " ")
  }
}
# need to change fadeyibii to fadeyibi in force, SCHUTZMANN to SCHUTZMAN in gps, DIIENNO to DIIENO in force, and the two andersons

for (i in 1:nrow(lookup_gps)) {
  if(!(lookup_gps$last[i] %in% lookup_force$last)){
    cat(lookup_gps$last[i], " ")
  }
}

# no additional changes needed from above
# Everything from gps is in force
# should loop through gps because force has full names and gps is contained in force

# set dummy first name for gps
lookup_gps$first = "DUMMY"

# only instance of double names are 3 instances of SMITH and 2 instances of GONZALES
for(i in 1:nrow(lookup_gps)){
  if(nrow(lookup_force %>% filter(last == lookup_gps$last[i])) > 1){
    first <- (lookup_force %>% filter(substring(lookup_force$Name, 1, 1) == word(lookup_gps$Name[i], -1), 
                                  last == lookup_gps$last[i]))$Name
    spaces <- str_count(first, pattern = " ")
    if (spaces == 1){
      first <- word(first, 1)
    }
    if(spaces == 2){
      first <- paste(word(first, 1), word(first, 2))
    }
    lookup_gps$first[i] <-  first
  }
  
  else{
    
    first <- word((lookup_force %>% filter(last == lookup_gps$last[i]))$Name, 1)
    lookup_gps$first[i] <-  first
    
  }
}

# full names for gps lookup
lookup_gps$full <- paste(lookup_gps$first, lookup_gps$last)



# full names for gps
for (i in 1:nrow(gps)){
  gps$`Player Name`[i] <- (lookup_gps %>% filter(Name == gps$`Player Name`[i]))$full
}

# rename gps Player Name to Name
gps <- gps %>% rename_at('Player Name', ~'Name')

## FINISHED NAMES



## START OF DATES

gps$Date <- as.Date(gps$Date)


for (i in 1:nrow(gps)){
  x <- as.Date(str_extract(gps$`Session Title`[i], "[0-9]+\\.[0-9]+\\.[0-9]{2}"), format = "%m.%d.%y")
  gps$Date[i] <- x
}



# force dates
force$Date <- as.Date(force$Date, format = "%m/%d/%y")

# END OF DATES

#only non chr col is Date
str(force)

## GET POSITION FOR GPS
gps$Position <- "DUMMY"

# position lookup force
lookup_force_position <- force %>% distinct(Name, Position)

length(unique(lookup_force$Name))


# Using lookup table for position, there don't appear to be players with multiple positions
for (i in 1:nrow(gps)){
  gps$Position[i] <- (lookup_force_position %>% filter(Name == gps$Name[i]))$Position
}

#moving position to front of table
gps <- gps %>% relocate(Position)

## END OF GETTING POSITION


## START PIVOT LONGER


## Adding time to session column
force$Type <- paste(force$Type, force$TestId)


#data with unimportant columns removed


gps_removed <- gps %>% 
  select(-"Split Start Time", -"Split End Time", -"Split Name")

force_removed <- force %>% 
  select(-"TestId", -"Time")

# The only non numeric cols of gps are the first five cols
str(gps_removed)


# The only non chr cols of force is Date
str(force_removed)



force_pivot <- pivot_longer(force_removed, cols = -c("Date", "Name", "Position", "Type", "Tags"), names_to = "Data Name", values_to = "Data Value")
force_pivot$Data_type <-  "Force"
force_pivot <- force_pivot %>% rename_at('Type', ~'Session')


gps_pivot <- pivot_longer(gps_removed, cols = -c("Date", "Session Title", "Position", "Name", "Tags"), names_to = "Data Name", values_to = "Data Value")
gps_pivot$Data_type <- "GPS"
gps_pivot <- gps_pivot %>% rename_at('Session Title', ~'Session')


# Reordering columns
force_pivot <- force_pivot %>% select("Name", "Date", "Position", "Data_type", "Session", "Tags", "Data Name", "Data Value")

gps_pivot <- gps_pivot %>% select("Name", "Date", "Position", "Data_type", "Session", "Tags", "Data Name", "Data Value")

#Joining data
joined <- rbind(force_pivot, gps_pivot)


## WRITING Joined DATA TO CSV
#write_csv(joined, file = "joined_data.csv")


# Getting shiny data
joined_force <- joined %>% filter(Data_type == "Force")

joined_GPS <- joined %>% filter(Data_type == "GPS")

joined_force <- pivot_wider(joined_force, names_from = "Data Name", values_from = "Data Value")
joined_GPS <- pivot_wider(joined_GPS, names_from = "Data Name", values_from = "Data Value")

names(joined_force)
names(joined_GPS)

# I picked the selected columns based on the provided video for force data
join_f2 <- joined_force %>% select(Name, Date, Position, Data_type, Session, Peak.Propulsive.Power, mRSI, Peak.Relative.Braking.Power, Relative.Peak.Landing.Force)

write_csv(join_f2, file = "shiny_force.csv")



# I picked the selected columns on what I guessed was important from GPS data
join_gps2 <- joined_GPS %>% select(Name, Date, Position, Data_type, Session, `Distance Per Min (yd/min)`, `Power Score (w/kg)`, `Work Ratio`, `Player Load Per Min`)

write_csv(join_gps2, file = "shiny_gps.csv")


unique(join_f2)